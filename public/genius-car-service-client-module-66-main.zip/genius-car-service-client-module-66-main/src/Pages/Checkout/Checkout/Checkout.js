import React from 'react';

const Checkout = () => {
    return (
        <div>
            <h2>Please Checkout your booking</h2>
        </div>
    );
};

export default Checkout;